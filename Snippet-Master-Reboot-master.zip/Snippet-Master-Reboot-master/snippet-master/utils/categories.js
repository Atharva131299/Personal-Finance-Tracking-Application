
const categories = [
    {
        id: '2',
        name: 'JavaScript',
    },
    {
        id: '3',
        name: 'CSS',
    },
    {
        id: '4',
        name: 'HTML',
    },
    {
        id: '5',
        name: 'React',
    },
    {
        id: '6',
        name: 'Node.js',
    },
    {
        id: '7',
        name: 'Hash Table',
    },
    {
        id: '8',
        name: 'Hash Table',
    },
    {
        id: '9',
        name: 'Node.js',
    },

]

export default categories;