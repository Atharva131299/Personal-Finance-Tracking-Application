import { gear, login, user } from "./Icons"


const pnaleMenu = [
    /*{
        id: 1,
        name: 'Profile',
        url: '/profile',
        icon: user,
    },*/
    {
        id: 2,
        name: 'Settings',
        url: '/profile/update',
        icon:gear,
    },
    {
        id: 3,
        name: 'Sign Out',
        url: '/signout',
        icon:login,
    },
]

export default pnaleMenu