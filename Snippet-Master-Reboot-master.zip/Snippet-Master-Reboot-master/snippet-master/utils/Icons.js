
export const bars = <i className="fa-solid fa-bars"></i>
export const add = <i className="fa-solid fa-plus"></i>
export const moon = <i className="fa-solid fa-moon"></i>
export const search = <i className="fa-solid fa-magnifying-glass"></i>
export const bell = <i className="fa-solid fa-bell"></i>
export const home = <i className="fa-solid fa-house"></i>
export const bookmarkIcon = <i className="fa-solid fa-bookmark"></i>
export const box = <i className="fa-solid fa-box"></i>
export const help = <i className="fa-solid fa-circle-info"></i>
export const gear = <i className="fa-solid fa-gear"></i>
export const login = <i className="fa-solid fa-right-to-bracket"></i>
export const user = <i className="fa-solid fa-user"></i>
export const join = <i className="fa-solid fa-user-plus"></i>
export const heart = <i className="fa-solid fa-heart"></i>
export const edit = <i className="fa-solid fa-file-pen"></i>
export const users = <i className="fa-solid fa-user-group"></i>
export const fire = <i class="fa-solid fa-fire-flame-curved"></i>
export const down = <i className="fa-solid fa-caret-down"></i>
export const trash = <i className="fa-solid fa-trash"></i>
export const admin = <i className="fa-solid fa-lock"></i>
export const copy = <i className="fa-solid fa-clipboard"></i>
export const githubIcon = <i className="fa-brands fa-github"></i>
export const linked = <i className="fa-brands fa-linkedin"></i>
export const mailIcon = <i className="fa-solid fa-envelope"></i>
export const expand = <i className="fa-solid fa-expand"></i>
export const plus = <i className="fa-solid fa-plus"></i>
export const xmark = <i className="fa-solid fa-xmark"></i>





