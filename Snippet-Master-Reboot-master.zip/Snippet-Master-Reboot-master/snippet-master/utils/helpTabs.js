const helpTabs = [
    {
        id: '1',
        title: 'Help?',
        link: '',
    },
    {
        id: '1',
        title: 'Licensing and Agreements',
        link: '',
    },
    {
        id: '2',
        title: 'Terms of Service',
        link: '',
    },
    {
        id: '3',
        title: 'Privacy Policy',
        link: '',
    }
]

export default helpTabs