import React from 'react'
import HelpSection from '../../Components/HelpSection/HelpSection'
import Layout from '../../Components/Layout'
import MainContent from '../../Components/MainContent/MainContent'

function index() {
    return (
        <React.Fragment>
            <HelpSection />
        </React.Fragment>
    )
}


export default index